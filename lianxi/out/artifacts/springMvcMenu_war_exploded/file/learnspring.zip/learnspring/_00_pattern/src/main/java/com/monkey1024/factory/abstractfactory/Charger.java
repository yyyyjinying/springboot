package com.monkey1024.factory.abstractfactory;

/**
 * 充电器的接口
 */
public interface Charger {

    void charge();
}
