package com.monkey1024.factory.abstractfactory;

/**
 * 手机
 */
public interface Telephone {
    void play();
}
