package com.monkey1024.factory.abstractfactory;

public class XiaoMi8 implements Telephone {

    @Override
    public void play() {
        System.out.println("小米8");
    }
}
