package com.monkey1024.factory.factorymethod;

/**
 * 苹果手机
 */
public interface IPhone {

    void play();
}
