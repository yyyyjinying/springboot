package com.monkey1024.factory.staticfactory;

/**
 * 苹果手机
 */
public interface IPhone {

    void play();
}
