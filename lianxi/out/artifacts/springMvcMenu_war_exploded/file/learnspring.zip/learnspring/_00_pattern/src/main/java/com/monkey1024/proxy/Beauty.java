package com.monkey1024.proxy;

/**
 * 女神
 */
public interface Beauty {

    void eat();

    void gift(int count);
}
