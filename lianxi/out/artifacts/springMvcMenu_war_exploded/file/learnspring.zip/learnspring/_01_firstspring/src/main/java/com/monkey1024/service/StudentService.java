package com.monkey1024.service;

public interface StudentService {

    void study();
}
