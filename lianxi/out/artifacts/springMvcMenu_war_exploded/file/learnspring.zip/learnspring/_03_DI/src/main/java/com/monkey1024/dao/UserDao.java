package com.monkey1024.dao;

public interface UserDao {

    void addUser();
}
