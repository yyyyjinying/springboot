package com.monkey1024.service;

public interface UserService {

    void addUser();
}
